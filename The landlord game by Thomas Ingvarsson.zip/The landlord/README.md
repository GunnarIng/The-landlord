The LandLord Text-based Game

This is my first JavaScript school project after reading JavaScript for 3 weeks. Learned alot during the project and relize that you can solve problems with alot of diffrent options with JavaScript. 


Thee Story:

This game is based on a sketch made by "Funny Or Die" with Will Ferrell and Pearl . "The LandLord"
src:https://www.youtube.com/watch?v=SIdxVR_7ikg&ab_channel=FunnyOrDie


In this story you have to make the right choices to avoid getting
evicted by the landlord. You will have 2 diffrent options when asked. make the right choices.


[Link To The Game](https://gunnaring.github.io/The-landlord/)














